using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using BusBookingApi.Data;
using BusBookingApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace BusBookingApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class LoginController : ControllerBase
{
    private readonly Context _Context;
    private readonly IConfiguration _configuration;
    public LoginController(IConfiguration configuration,Context Context)
    {
        _Context = Context;
         _configuration = configuration;
    }
    public string? userName ;
    
    [HttpGet("GetLoginByCredentials")]
    public async Task<ActionResult<login>> GetLoginByCredentials(string userName, string password)
    {
        var login = await _Context.login.FirstOrDefaultAsync(l => l.username == userName && l.password == password);

        if (login == null)
        {
            return NotFound();
        }
        var tokenString = GenerateToken(userName);

        return Ok(tokenString);
    }
    private string GenerateToken(string? username){
            if(username is null )
            { return "";
            }
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JwtConfig:key"]));
            var credentials = new SigningCredentials(key,SecurityAlgorithms.HmacSha256);
            var claims = new[]{
                new Claim("Email", username),
                
            };
            var token = new JwtSecurityToken(
                issuer: _configuration["JwtConfig:Issuer"],
                audience: _configuration["JwtConfig:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: credentials
            );
            return tokenHandler.WriteToken(token);
        }


    [HttpGet]
    public async Task<ActionResult<IEnumerable<login>>> TotalUser()
    {
        var TotalUsers = await _Context.login.ToListAsync();
        return Ok(TotalUsers);
    }
}