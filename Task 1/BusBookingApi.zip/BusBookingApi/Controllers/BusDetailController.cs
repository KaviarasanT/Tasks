using BusBookingApi.Data;
using BusBookingApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BusBookingApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BusDetailController : ControllerBase
    {
        private readonly Context _context;

        public BusDetailController(Context context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<busdetail>>> TotalBus()
        {
            var totalBusDetails = await _context.busdetail.ToListAsync();
            return Ok(totalBusDetails);
        }

        [HttpPost]
        public async Task<ActionResult<busdetail>> AddBusDetail([FromBody] busdetail busDetail)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.busdetail.Add(busDetail);
                    await _context.SaveChangesAsync();
                    return CreatedAtAction(nameof(GetBusDetailById), new { sno = busDetail.sno }, busDetail);
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            return BadRequest(ModelState);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<busdetail>> GetBusDetailById(int sno)
        {
            var busDetail = await _context.busdetail.FindAsync(sno);
            if (busDetail == null)
            {
                return NotFound();
            }
            return Ok(busDetail);
        }

        [HttpGet("GetByRegistrationNo/{registrationNo}")]
        public async Task<ActionResult<busdetail>> GetBusDetailByRegistrationNo(string registrationNo)
        {
            var busDetail = await _context.busdetail.FirstOrDefaultAsync(b => b.registrationno == registrationNo);

            if (busDetail == null)
            {
                return NotFound();
            }

            return Ok(busDetail);
        }
    }
}
