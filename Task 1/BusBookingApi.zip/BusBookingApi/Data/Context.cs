using Microsoft.EntityFrameworkCore;
// using BusBookingApp.bus;
using BusBookingApi.Models;

namespace BusBookingApi.Data
{
    public class Context : DbContext
    {
        public DbSet<login>? login { get; set; }
        public DbSet<busdetail>? busdetail { get; set; }
        // public DbSet<Ratting>? busRatting { get; set; }
        public DbSet<busname>? busname { get; set; }
        public DbSet<users>? users { get; set; }
        
        public Context(DbContextOptions options) : base(options)
        {
        }
    }
}

