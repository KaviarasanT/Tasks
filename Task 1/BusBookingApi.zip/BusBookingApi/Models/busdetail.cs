using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace BusBookingApi.Models
{
    public class busdetail
    {
       [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int sno { get; set; }

        [Required(ErrorMessage = "Bus Name is required")]
        [StringLength(20, ErrorMessage = "Bus Name must be at most 20 characters")]
        public string? name { get; set; }
        
        [Required]
        [RegularExpression(@"^[A-Z]{2}-\d{2}-[A-Z]{1,2}-\d{4}$", ErrorMessage = "Invalid bus number")]
        public string? registrationno { get; set; }
        public string? busfare { get; set; }

        [Required(ErrorMessage = "Bus Type is required")]
        public string? bustype { get; set; }
        // public string? newspaper { get; set; }
        public string? water { get; set; }
        // public string? charging { get; set; }
        // public string? travelsnumber1 { get; set; }
        // public string? travelsnumber2 { get; set; }

        [Required(ErrorMessage = "Source is required")]
        public string? source { get; set; }

        [Required(ErrorMessage = "Destination is required")]
        public string? destination { get; set; }
        public string? pickupDate{get;set;}
        public string? pickuptime { get; set; }
        public string? dropDate{get;set;}
        public string? droptime { get; set; }

    }
}