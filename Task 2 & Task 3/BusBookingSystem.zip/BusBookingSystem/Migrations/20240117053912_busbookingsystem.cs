﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BusBookingWeb.Migrations
{
    /// <inheritdoc />
    public partial class busbookingsystem : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "busdetail",
                columns: table => new
                {
                    sno = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    registrationno = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    busfare = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    bustype = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    water = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    source = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    destination = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    pickupDate = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    pickuptime = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    dropDate = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    droptime = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_busdetail", x => x.sno);
                });

            migrationBuilder.CreateTable(
                name: "busname",
                columns: table => new
                {
                    sno = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    busno = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    pickupDate = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    pickupplace = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    pickuptime = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    dropDate = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    dropplace = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    droptime = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _5 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _6 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _7 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _8 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _9 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _10 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _11 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _12 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _13 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _14 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _15 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _16 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _17 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _18 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _19 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _20 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _21 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _22 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _23 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _24 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _25 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _26 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _27 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _28 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _29 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _30 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _31 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _32 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _33 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _34 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _35 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _36 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _37 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _38 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _39 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _40 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _41 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _42 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _43 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    _44 = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_busname", x => x.sno);
                });

            migrationBuilder.CreateTable(
                name: "busrattings",
                columns: table => new
                {
                    sno = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    username = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    rattings = table.Column<int>(type: "int", nullable: false),
                    command = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    busname = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_busrattings", x => x.sno);
                });

            migrationBuilder.CreateTable(
                name: "login",
                columns: table => new
                {
                    sno = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    username = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    phonenumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    password = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_login", x => x.sno);
                });

            migrationBuilder.CreateTable(
                name: "users",
                columns: table => new
                {
                    sno = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    username = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    busname = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    registrationno = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    seatno = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    busfare = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    newspaper = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    water = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    charging = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    source = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    destination = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    pickupDate = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    pickuptime = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    dropDate = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    droptime = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_users", x => x.sno);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "busdetail");

            migrationBuilder.DropTable(
                name: "busname");

            migrationBuilder.DropTable(
                name: "busrattings");

            migrationBuilder.DropTable(
                name: "login");

            migrationBuilder.DropTable(
                name: "users");
        }
    }
}
