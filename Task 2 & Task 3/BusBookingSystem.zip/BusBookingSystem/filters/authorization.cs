using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
namespace BusBookingsys.Authorization
{
    
public class CustomAuthorizationFilter : Attribute,IAuthorizationFilter
    {
         public void OnAuthorization(AuthorizationFilterContext context)
    {
        
        string username=context.HttpContext.Session.GetString("username");
        if (username==null)
        {
            
            context.Result = new RedirectToActionResult("Login","Main",null);
            return;
        }
        Console.WriteLine(username);
    }

}

}