using BusBookingWeb.Connections;
using System.Linq;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using BusBookingWeb.Models;
using BusBookingWeb.Connections;
using System.Net;
using System.Net.Mail;
using Microsoft.EntityFrameworkCore;
using BusBookingWeb.bus;
using System.Collections.Generic;

public class Crud
{
    Context context=new Context();
    public string? username;  
    public void getRegister(login register)
    {
        username=register.username;
        context.login.Add(register);
        context.SaveChanges();
    }
       
    public string getlogin(login login)
    {
        // Console.WriteLine(login.username);
        // Console.WriteLine(login.password);
        username=login.username;
        var user = context.login.Where(p => p.username== login.username && p.password==login.password).FirstOrDefault();
        if(user !=null)
        {
            return "ok";
        }
        else
        {
            return "notok"; 
        }
    }
    public List<login> Logindetails(string username)
    {
        var user = context.login.Where(p => p.username == username).ToList();
        return user;
    }
    public string userid()
    {
        return username;
    }
    public void forgetpassword(login login)
    {
        var user = context.login.FirstOrDefault(p => p.email == login.email);
        if(user != null)
        {
            user.password = login.password; 
            context.SaveChanges();
        }
        else 
        {
            Console.WriteLine("NULL");
        }
    }

    public List<busdetail> getList(string sourse, string destination)
    {
        List<busdetail> buslist=new List<busdetail>();
        buslist = context.busdetail.Where(p => p.source == sourse && p.destination == destination ).ToList();
        // Console.WriteLine("returned getbus"); 
        return buslist;
    }
    public busdetail getBusdetail(string BusNo)
    {
        busdetail busdetails = new busdetail();
        busdetails = context.busdetail.Where(p=>p.registrationno == BusNo).SingleOrDefault();
        return busdetails;
    }

    public List<busdetail> totalBusdetail()
    {
        var busdetail = context.busdetail.Where(x => true).ToList();
        if(busdetail == null)
        {
            return null;
        }
        else
        {
            return busdetail;
        }
    }
    public void deleteBus(string registrationno)
    {
        var delete = context.busdetail.SingleOrDefault(d => d.registrationno == registrationno);
        if(delete != null)
        {
            context.busdetail.Remove(delete);
            context.SaveChanges();
        }
    }
    public busname getbus(string bus)
    {
        busname bus1=new busname();
        // Console.WriteLine(bus);
        bus1 = context.busname.Where(p=>p.busno == bus).SingleOrDefault();            
        return bus1;
    }
    public void updateBus(busdetail newbusdetails)
    {
        busdetail busdetail = context.busdetail.FirstOrDefault(p=>p.registrationno == newbusdetails.registrationno);
        if (busdetail != null)
        {
            busdetail.name = newbusdetails.name;
            busdetail.source = newbusdetails.source;
            busdetail.destination = newbusdetails.destination;
            busdetail.busfare = newbusdetails.busfare;
            busdetail.bustype = newbusdetails.bustype;
            busdetail.dropDate = newbusdetails.dropDate;
            busdetail.droptime = newbusdetails.droptime;
            busdetail.pickupDate = newbusdetails.pickupDate;
            busdetail.pickuptime = newbusdetails.pickuptime;
            busdetail.water = newbusdetails.water;

            context.SaveChanges();
        }
    }
    public busdetail getfullBusDetail(string busno)
    {
        busdetail busdetail = new busdetail();
        busdetail = context.busdetail.Where(p=>p.registrationno == busno).FirstOrDefault();
        return busdetail;
    }
    public List<login> GetMyAccount(string username)
    {
        List<login> Login = new List<login>();
        Login = context.login.Where(p=>p.username == username).ToList();
        return Login;
    }
    public void updateseats(List<string> buttonvalues, string busno, string type,string username)
    {
        var BusDetail = context.busdetail.Where(p=>p.registrationno==busno).ToList();
        
        string seatno="";
        string seatno1="";
        var bus = context.busname.Where(p => p.busno == busno).SingleOrDefault();
        var user = context.users.Where(p=>p.username == username & p.registrationno == busno).ToList();
        foreach(var item in user)
        {
            context.users.Remove(item);
        }
        
        if(bus!=null)
        {
            if(type=="update")
            {
                foreach (var item in buttonvalues)
                {
                    if (item != "0")
                    {
                        seatno=seatno+item+",";
                        string seat = "_" + item;  
                        var seatProperty = typeof(busname).GetProperty(seat);
                        if (seatProperty != null)
                        {
                            seatProperty.SetValue(bus, username);
                            context.SaveChanges();
                        }
                    }
                }
                

            } 
            if(type=="cancel")
            {
                foreach (var item in buttonvalues)
                {
                    string seat = "_" + item; 
                    var seatProperty = typeof(busname).GetProperty(seat);
                    // Console.WriteLine(item);
                if (item != "0")
                {
                        seatno=seatno+item+","; 
                        if (seatProperty != null)
                        {                   
                        seatProperty.SetValue(bus, null);
                        }        

                    }   
                    context.SaveChanges();
                }   
                
            }
            
            if( bus._1==username)
            {
                seatno1=seatno1+"1"+",";
            }
            if( bus._2==username)
            {
                seatno1=seatno1+"2"+",";                
            }
            if( bus._3==username)
            {
                seatno1=seatno1+"3"+",";                
            }
            if( bus._4==username)
            {
                seatno1=seatno1+"4"+",";;                
            }
            if( bus._5==username)
            {
                seatno1=seatno1+"5"+",";                
            }
            if( bus._6==username)
            {
                seatno1=seatno1+"6"+",";                
            }
            if( bus._7==username)
            {
                seatno1=seatno1+"7"+",";                
            }
            if( bus._8==username)
            {
                seatno1=seatno1+"8"+",";                
            }
            if( bus._9==username)
            {
                seatno1=seatno1+"9"+",";                
            }
            if(  bus._10==username)
            {
                seatno1=seatno1+"10"+",";                
            }
            if( bus._11==username)
            {
                seatno1=seatno1+"11"+",";
            }
            if(  bus._12==username)
            {
                seatno1=seatno1+"12"+",";                
            }
            if(  bus._13==username)
            {
                seatno1=seatno1+"13"+",";                
            }
            if(  bus._14==username)
            {
                seatno1=seatno1+"14"+",";                
            }
            if( bus._15==username)
            {
                seatno1=seatno1+"15"+",";                
            }
            if(bus._16==username)
            {
                seatno1=seatno1+"16"+",";               
            }
            if(bus._17==username)
            {
                seatno1=seatno1+"17"+",";                
            }
            if( bus._18==username)
            {
                seatno1=seatno1+"18"+",";                
            }
            if(bus._19==username)
            {
                seatno1=seatno1+"19"+",";                
            }
            if( bus._20==username)
            {
                seatno1=seatno1+"20"+",";                
            }     
            if(  bus._21==username)
            {
                seatno1=seatno1+"21"+",";
            }
            if( bus._22==username)
            {
                seatno1=seatno1+"22"+",";                
            }
            if( bus._23==username)
            {
                seatno1=seatno1+"23"+",";                
            }
            if(bus._24==username)
            {
                seatno1=seatno1+"24"+",";                
            }
            if( bus._25==username)
            {
                seatno1=seatno1+"25"+",";                
            }
            if( bus._26==username)
            {
                seatno1=seatno1+"26"+",";                
            }
            if(bus._27==username)
            {
                seatno1=seatno1+"27"+",";                
            }
            if(bus._28==username)
            {
                seatno1=seatno1+"28"+",";                
            }
            if( bus._29==username)
            {
                seatno1=seatno1+"29"+",";                
            }
            if(bus._30==username)
            {
                seatno1=seatno1+"30"+",";                
            }  
            if( bus._31==username)
            {
                seatno1=seatno1+"31"+",";
            }
            if( bus._32==username)
            {
                seatno1=seatno1+"32"+",";                
            }
            if(bus._33==username)
            {
                seatno1=seatno1+"33"+",";                
            }
            if(bus._34==username)
            {
                seatno1=seatno1+"34"+",";                
            }
            if(bus._35==username)
            {
                seatno1=seatno1+"35"+",";                
            }
            if(bus._36==username)
            {
                seatno1=seatno1+"36"+",";                
            }
            if(bus._37==username)
            {
                seatno1=seatno1+"37"+",";                
            }
            if( bus._38==username)
            {
                seatno1=seatno1+"38"+",";                
            }
            if( bus._39==username)
            {
                seatno1=seatno1+"39"+",";                
            }
            if( bus._40==username)
            {
                seatno1=seatno1+"40"+",";                
            } 
            if( bus._41==username)
            {
                seatno1=seatno1+"41"+","; 
            }
            if( bus._42==username)
            {
                seatno1=seatno1+"42"+",";                 
            }
            if( bus._43==username)
            {
                seatno1=seatno1+"43"+",";                 
            }
            if(bus._44==username)
            {
                seatno1=seatno1+"44"+",";                 
            }
                // string Busname = 
            foreach (var item in BusDetail)
            {
                users user1=new users{username=username,busname=item.name,registrationno=busno,seatno=seatno1,busfare=item.busfare,source=bus.pickupplace ,destination=bus.dropplace, pickupDate=bus.pickupDate, pickuptime=bus.pickuptime, dropDate=bus.dropDate, droptime=bus.droptime};
                context.users.Add(user1);
                context.SaveChanges();
            }                
                //Console.WriteLine("seatno1...");
            // Console.WriteLine(bus._31);
                //Console.WriteLine(seatno1);      
        }
        // else
        // {
        //     Console.WriteLine("Null");
        // }
    }
    public List<users> getbookedbuses(string username)
    { 
        var  bookedbus=context.users.Where(p=>p.username==username).ToList();
        foreach (var item in bookedbus)
        {
            if(item.seatno == "" )
            {
                return null;
            }
            else
            {
                break;
            }
        }
        return bookedbus;
    }

    public void modifypassword(login login,string newpassword)
    {
        var user = context.login.Where(p => p.username == login.username && p.password == login.password).FirstOrDefault();
        if(user != null)
        {
            user.password = newpassword; 
            context.SaveChanges();
        }
    }
    public void modifyPhonenumber(login login,string phonenumber)
    {
        var user = context.login.Where(un => un.username==login.username && un.password ==login.password).FirstOrDefault();
        user.phonenumber = phonenumber;
        context.SaveChanges();
    }
    public void modifyEmail(login login,string email)
    {
        var phone = context.login.Where(un => un.username==login.username && un.password ==login.password).FirstOrDefault();
        phone.email = email;
        context.SaveChanges();
    }

    public void addBus(busdetail addbus)
    {
        var adbus=new busname{
            busno=addbus.registrationno,
            pickupDate=addbus.pickupDate,
            pickupplace=addbus.source,
            pickuptime=addbus.pickuptime,
            dropDate=addbus.dropDate,
            dropplace=addbus.destination,
            droptime=addbus.droptime

        };
        context.busname.Add(adbus);
        context.busdetail.Add(addbus);
        context.SaveChanges();
    }

    public List<login> TotalUser()
    {
        List<login> TotalUsers = new List<login>();
        TotalUsers = context.login.Where(x=> true).ToList();
        return TotalUsers;
    }
}