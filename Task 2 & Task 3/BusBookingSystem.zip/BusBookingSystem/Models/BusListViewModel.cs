using BusBookingWeb.bus;
namespace BusBookingWeb.bus
{
    public class BusListViewModel
    {
        public busdetail? BusDetails { get; set; }
        public busname? busname { get; set; }
    }
}