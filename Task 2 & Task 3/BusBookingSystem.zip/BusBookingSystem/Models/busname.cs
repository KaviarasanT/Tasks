using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

    public class busname
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int sno {get;set;}
        
    [Required]
    [RegularExpression(@"^[A-Z]{2}-\d{2}-[A-Z]{1,2}-\d{4}$", ErrorMessage = "Invalid bus number")]
    public string? busno{get;set;}
    public string? pickupDate{get;set;}
    public string? pickupplace{get;set;}
    public string? pickuptime { get; set; }
    public string? dropDate{get;set;}
    public string? dropplace{get;set;}
    public string? droptime { get; set; }
    public string? _1 {get;set;}
    public string? _2 {get;set;}
    public string? _3 {get;set;}
    public string? _4 {get;set;}
    public string? _5 {get;set;}
    public string? _6 {get;set;}
    public string? _7 {get;set;}
    public string? _8 {get;set;}
    public string? _9 {get;set;}
    public string? _10 {get;set;}
    public string? _11 {get;set;}
    public string? _12 {get;set;}
    public string? _13 {get;set;}
    public string? _14 {get;set;}
    public string? _15 {get;set;}
    public string? _16 {get;set;}
    public string? _17 {get;set;}
    public string? _18 {get;set;}
    public string? _19 {get;set;}
    public string? _20 {get;set;}
    public string? _21 {get;set;}
    public string? _22 {get;set;}
    public string? _23 {get;set;}
    public string? _24 {get;set;}
    public string? _25 {get;set;}
    public string? _26 {get;set;}
    public string? _27 {get;set;}
    public string? _28 {get;set;}
    public string? _29 {get;set;}
    public string? _30 {get;set;}
    public string? _31 {get;set;}
    public string? _32 {get;set;}
    public string? _33 {get;set;}
    public string? _34 {get;set;}
    public string? _35 {get;set;}
    public string? _36 {get;set;}
    public string? _37 {get;set;}
    public string? _38 {get;set;}
    public string? _39 {get;set;}
    public string? _40 {get;set;}
    public string? _41 {get;set;}
    public string? _42 {get;set;}
    public string? _43 {get;set;}
    public string? _44 {get;set;}
}