using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using BusBookingWeb.bus;

namespace BusBookingWeb.Connections
{
    //SqlConnection? sqlConnection;    
    //string ?ConnectionString=@;
    
    /*public void getConnection()
    {
        sqlConnection = new SqlConnection("data source=DESKTOP-9MH9KIG\\SQLEXPRESS;initial catalog=busbookingweb;trusted_connection=true");
        Console.WriteLine("Connection established");
        

    }*/
    public class Context : DbContext
    {
        public DbSet<login>? login { get; set; }
        public DbSet<busdetail>? busdetail { get; set; }
        public DbSet<ratting>? busrattings { get; set; }
        public DbSet<busname>? busname { get; set; }
        public DbSet<users>? users { get; set; }
        // public IEnumerable<BusListViewModel> BusListViewModel { get; internal set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("data source=ASPLAP1848;TrustServerCertificate=True;initial catalog=busbooking;trusted_connection=true");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<login>()
                .HasKey(u => u.sno);
 
            modelBuilder.Entity<busdetail>()
                .HasKey(u => u.sno);
 
            modelBuilder.Entity<ratting>()
                .HasKey(c => c.sno);
 
            modelBuilder.Entity<busname>()
                .HasKey(c => c.sno);
 
            modelBuilder.Entity<users>()
                .HasKey(c => c.sno);
 
            
        }
            
    }
}

