using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using BusBookingWeb.Models;
using BusBookingWeb.Connections;
using BusBookingWeb.bus;
using System.Collections.Generic;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Net;
using System.Net.Mail;
using System.Linq;
using Microsoft.AspNetCore.Http;

namespace BusBookingWeb.Controllers;

public class EditController : Controller
{
    Crud crud=new Crud(); 
    string? username; 

    string? getusername;
    [HttpGet]
    public IActionResult ChangePhoneNumber()
    {
        return View();
    }
    [HttpPost]
    public IActionResult ChangePhoneNumber(string username,string password,string phonenumber)
    {
        ViewBag.getusername = HttpContext.Session.GetString("username");
        login login = new login();
        login.username = username;
        login.password = password;
        ViewBag.username = phonenumber;

        string? confirm= crud.getlogin(login);
        if(confirm == "ok")
        {
            crud.modifyPhonenumber(login,phonenumber);
            return RedirectToAction("HomePage","Client");
        }
        else
        {
            return View("ChangePhoneNumber");
        }
        // return View();
    }
    [HttpGet]
    public IActionResult ChangePassword()
    {
        return View();
    }
    [HttpPost]
    public IActionResult ChangePassword(string username,string password,string newpassword)
    {
        ViewBag.getusername = HttpContext.Session.GetString("username");
        login login = new login();
        login.username=username;
        login.password=password;
        string? newPassword = newpassword;
        // Console.WriteLine(login.username);
        // Console.WriteLine(login.password);
        // Console.WriteLine(newpassword);
        string? confirm= crud.getlogin(login);
        if(confirm == "ok")
        {
            crud.modifypassword(login , newPassword);
            return RedirectToAction("HomePage","Client");
        }
        else
        {
            return View("ChangePassword");
        }
        // return View();
    }
    [HttpGet]
    public IActionResult ChangeEmail()
    {
        return View();
    }

    [HttpPost]
    public IActionResult ChangeEmail(string username,string password,string email)
    {
        ViewBag.getusername = HttpContext.Session.GetString("username");
        login login = new login();
        login.username = username;
        login.password = password;
        ViewBag.email = email;

        string? confirm= crud.getlogin(login);
        if(confirm == "ok")
        {
            crud.modifyEmail(login,email);
            return RedirectToAction("HomePage","Client");
        }
        else
        {
            return View("ChangeEmail");
        }
        // return View();
    }
}