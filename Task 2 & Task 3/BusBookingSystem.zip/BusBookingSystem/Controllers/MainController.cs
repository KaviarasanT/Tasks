using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using BusBookingWeb.Models;
using BusBookingWeb.Connections;

namespace BusBookingWeb.Controllers;

public class MainController : Controller
{
    public IActionResult Index()
    {
        return View();
    }
    public IActionResult Login()
    {
        return View();
    }
}