using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using BusBookingWeb.Models;
using BusBookingWeb.Connections;
using BusBookingWeb.bus;
using System.Collections.Generic;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Net;
using System.Net.Mail;
using System.Linq;
using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using BusBookingsys.Authorization;
using Microsoft.AspNetCore.Authorization;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using System.Security.Cryptography;
public class ClientController : Controller
{
    
    Crud crud=new Crud();    
    string? username;
    
    
    public IActionResult loginuser()
    {
        login login=new login();

        ViewBag.username = Request.Form["username"];
        login.username = Request.Form["username"];
        login.password = Request.Form["password"];       
        HttpContext.Session.SetString("username",login.username);
        username=Request.Form["username"];
        string? confirm= crud.getlogin(login);
        
        if((login.username=="Admin" || login.username=="admin") && (login.password=="Admin@123"))
        {
            
            return RedirectToAction("AddBus","Admin");
        }
        else if(confirm=="ok")
        {
            ViewBag.username=username;
            
            return View("HomePage");
        }
        else
        {
            return RedirectToAction("Login","Main");
        }
    }
   

    public IActionResult Registeruser(login model)
    {
        Console.WriteLine(ModelState.IsValid);
        if(!ModelState.IsValid)
        {
            return RedirectToAction("Register",model);
        } 
        else
        {
            login login=new login();
        login.username=Request.Form["username"];
        login.email=Request.Form["email"];
        login.phonenumber=Request.Form["phonenumber"];
        login.password=Request.Form["password"];
        username=Request.Form["username"];       
        HttpContext.Session.SetString("username",login.username);
        ViewBag.username = HttpContext.Session.GetString("username");
        crud.getRegister(login);
        return View("HomePage");
        }
        
    }  
   
    public IActionResult Forgotview()
    {
        return View ("Forgot");
    }  
    public IActionResult login()
    {        
        return View ("login");   
    }
    public IActionResult Register()
    {
        return View ();
    }
    public IActionResult Resetview()
    {    
        return View ("Reset");        
    }  
    public IActionResult resetpassword()
    {
        login login=new login();
        login.email=Request.Form["email"];
        login.password=Request.Form["password"];
        
        crud.forgetpassword(login);
        ViewBag.username=HttpContext.Session.GetString("username");
        return RedirectToAction("Login","Main");
    }
    [CustomAuthorizationFilter]
        public IActionResult getHome()
    {
        // username=crud.userid();    
        ViewBag.username=HttpContext.Session.GetString("username");
        return View("HomePage");
    } 
    [CustomAuthorizationFilter]
    public IActionResult getsearch(busdetail busdetails)
    {
        string? source = busdetails.source;
        string? destination = busdetails.destination;
        string? date = busdetails.pickupDate;

        List<busdetail> buslist=new List<busdetail>();
        buslist =crud.getList(source,destination);

        return View ("BusList",buslist);
    }
    public IActionResult getBookedbus()
    {
        username=HttpContext.Session.GetString("username");
        ViewBag.Bookings=crud.getbookedbuses(username);
        ViewBag.username = username;
        if (ViewBag.Bookings == null)
        {
            return View("EmptyView");
        }
        return View ("Bookedbus");        
    }
    public IActionResult EmptyView()
    {
        return View();
    }
    [CustomAuthorizationFilter]
    public IActionResult PrintTicket(int ticketId)
    {
        using (var context = new Context())
        {
            var ticket = context.users.Find(ticketId);

            byte[] pdfBytes;
            using (var ms = new MemoryStream())
            {
                var document = new Document(PageSize.A4, 50, 50, 25, 25);
                var writer = PdfWriter.GetInstance(document, ms);
                document.Open();
                document.Add(new Paragraph("Ticket Information"));           
                document.Add(new Paragraph($"Passenger Name: {ticket.username}"));
                document.Add(new Paragraph($"Bus no: {ticket.registrationno}"));
                document.Add(new Paragraph($"Pickup Place: {ticket.source}"));
                document.Add(new Paragraph($"Date: {ticket.pickupDate}"));
                document.Add(new Paragraph($"Time: {ticket.pickuptime}"));
                document.Add(new Paragraph($"Drop Place: {ticket.destination}"));
                document.Add(new Paragraph($"Drop Place: {ticket.seatno}"));
                document.Close();
                pdfBytes = ms.ToArray();
            }

            return File(pdfBytes, "application/pdf", "ticket.pdf");
        }
    }
[CustomAuthorizationFilter]
    public IActionResult CancelTicket(string bus,string sno)
    {
        Context context=new Context();
        ViewBag.busname=context.busname.Where(p=>p.busno==bus).SingleOrDefault();
        username=HttpContext.Session.GetString("username");
        ViewBag.username=username;
        ViewBag.sno=sno;
        // Console.WriteLine(ViewBag.busname.busno);
        return View ("CancelTicket");
    }   
    
    public void sendMail()
    {
        MailMessage mailMessage = new MailMessage();
        mailMessage.From = new MailAddress("praveenkumar.1903112@srec.ac.in");
        string? email=Request.Form["email"];
        mailMessage.To.Add(email);
        mailMessage.Subject = "Reset your password";
        mailMessage.Body = "Please click on the following link to reset your password: " + "https://localhost:7121/Client/Resetview";

        SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587);
        smtpClient.UseDefaultCredentials = false;
        smtpClient.Credentials = new NetworkCredential("praveenkumar.1903112@srec.ac.in", "Praveen24@");
        smtpClient.EnableSsl = true;
        smtpClient.Send(mailMessage); 
    }
    public IActionResult getbus(string bus)
    {
        // Console.WriteLine(bus);
        busdetail busdetails = new busdetail();
        busdetails = crud.getBusdetail(bus);
        ViewBag.busdetails = busdetails;
        busname bustable=new busname();
        bustable=crud.getbus(bus);
        
        ViewBag.busname=bustable;
        ViewBag.username=HttpContext.Session.GetString("username");
        return View ("BusSeatSelect");
    } 
    public IActionResult selectedseats(List<string> buttonvalues,string busno,string type )
    {
       
        if(buttonvalues==null)
        {
        }
        else
        {    
            username=HttpContext.Session.GetString("username");      
            crud.updateseats(buttonvalues,busno,type,username);
        }
        ViewBag.username=HttpContext.Session.GetString("username");
        return RedirectToAction("getHome");
    }
    [CustomAuthorizationFilter]
    public IActionResult Help()
    {
        ViewBag.username=HttpContext.Session.GetString("username");
        return View();
    }
    public IActionResult Logout()
    {
        return View();
    }

    public IActionResult GetMyAccount()
    {
        string username = HttpContext.Session.GetString("username");
        List<login> login = new List<login>();
        login = crud.GetMyAccount(username);
        // ViewBag.UserDetails = login ;
        return View("MyAccount",login);
    }
    [CustomAuthorizationFilter]
    public IActionResult Homepage()
    {
        ViewBag.username = HttpContext.Session.GetString("username");
        return View();
    }
}