using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using BusBookingWeb.Models;
using BusBookingWeb.Connections;
using BusBookingWeb.bus;
using System.Collections.Generic;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Net;
using System.Net.Mail;
using System.Linq;
using Microsoft.AspNetCore.Http;

namespace BusBookingWeb.Controllers;

public class AdminController : Controller
{   
    Crud crud = new Crud(); 
    string? username; 
    string? getusername;
    public IActionResult AddBus()
    {
        return View ("AddBus");
    }
    public IActionResult totalBus()
    {
        List<busdetail> busdetails =new List<busdetail>();
        busdetails = crud.totalBusdetail();
        if(busdetails == null)
        {
            return RedirectToAction("EmptyView","Client");
        }
        return View ("TotalBus",busdetails);
    }
    public IActionResult RemoveBus(string registrationno)
    {
        // Console.WriteLine(registrationno);
        // busdetail busdetail = new busdetail();
        crud.deleteBus(registrationno);
        return RedirectToAction("totalBus");
    }
    public IActionResult EditBus()
    { 
        return View ("EditBus");    
    }
    [HttpGet]
    public IActionResult Edit(string registrationno)
    {
        busdetail busdetails = new busdetail();
        busdetails=crud.getfullBusDetail(registrationno);
        return View(busdetails);
    }
    [HttpPost]
    public IActionResult Edit(busdetail busdetails)
    {
        crud.updateBus(busdetails);
        return RedirectToAction("totalBus");
    }
    public IActionResult Settings()
    {    
        return View ("Settings");    
    }
    public IActionResult InsertBus(busdetail busdetail)
    {
        // Console.WriteLine(busdetail.name);
        crud.addBus(busdetail);
        return View("AddBus");
    }
    [HttpGet]
    public IActionResult UserProfiles()
    {
        List<login> login = new List<login>();
        login = crud.TotalUser();
        return View("UserDetails",login);
    }
}
